# agents/agent.py

from skills.light_control import turn_on_light, turn_off_light, set_brightness
from langchain import LLMChain, PromptTemplate
from langchain.llms import OpenAI

# инициализация LLM
llm = OpenAI(model="gpt-4o-mini")

tools = {
    "turn_on_light": turn_on_light,
    "turn_off_light": turn_off_light,
    "set_brightness": set_brightness,
}

# PromptTemplate с чёткими ограничениями
template = """
Ты — ассистент «умного дома». У тебя есть три инструмента:

1) turn_on_light(text: str) -> str  
   — включает лампу (on_off)  
2) turn_off_light(text: str) -> str  
   — выключает лампу (on_off)  
3) set_brightness(text: str) -> str  
   — меняет яркость (только у устройств с поддержкой brightness)

ВАЖНО:
- Вызывай set_brightness **только** если пользователь **в явном виде** просил изменить яркость.
- Никогда не «проверяй состояние» лампы, не вызывай инструменты повторно после того, как действие выполнено.
- Если инструмент возвращает ошибку про неподдержку, сразу переходи к финальному ответу.

Используй формат:
Question: {input_data}
Thought: <твой внутренний рассуждение>
Action: <имя инструмента>
Action Input: <текст>
Observation: <ответ инструмента>
...
Thought: Я знаю ответ
Final Answer: <что сказать пользователю>

Begin!
"""

prompt = PromptTemplate(template=template, input_variables=["input_data"])
agent_chain = LLMChain(llm=llm, prompt=prompt)

def run_agent(input_text: str) -> str:
    return agent_chain.run(input_data=input_text)

# skills/light_control.py

from utils.house_config import parse_room_device, get_device_info

def turn_on_light(text: str) -> str:
    info = parse_room_device(text)
    room = info["room_id"]
    dev_id = info["device_id"]
    if dev_id is None:
        return "Не смог найти устройство для включения."
    if room is None:
        return "Не смог определить комнату."
    dev = get_device_info(room, dev_id)
    if dev is None or "on_off" not in dev.get("capabilities", []):
        return "Устройство не поддерживает включение/выключение."
    # здесь ваша логика MQTT/API
    name = dev.get("name", dev_id)
    return f"Выполнено действие: включение «{name}» в комнате «{room}»"

def turn_off_light(text: str) -> str:
    info = parse_room_device(text)
    room = info["room_id"]
    dev_id = info["device_id"]
    if dev_id is None:
        return "Не смог найти устройство для выключения."
    if room is None:
        return "Не смог определить комнату."
    dev = get_device_info(room, dev_id)
    if dev is None or "on_off" not in dev.get("capabilities", []):
        return "Устройство не поддерживает включение/выключение."
    name = dev.get("name", dev_id)
    return f"Выполнено действие: выключение «{name}» в комнате «{room}»"

def set_brightness(text: str) -> str:
    info = parse_room_device(text)
    room = info["room_id"]
    dev_id = info["device_id"]
    if dev_id is None:
        return "Не смог найти устройство для установки яркости."
    if room is None:
        return "Не смог определить комнату."
    dev = get_device_info(room, dev_id)
    if dev is None or "brightness" not in dev.get("capabilities", []):
        return "Устройство не поддерживает изменение яркости."
    # TODO: из текста вытащить процент и отправить команду
    name = dev.get("name", dev_id)
    return f"Выполнено действие: установка яркости «{name}» в комнате «{room}»"

# utils/house_config.py

import inspect
from pathlib import Path
import yaml
from pymorphy2 import MorphAnalyzer

# патч для pymorphy2 под Py3.13
if not hasattr(inspect, "getargspec"):
    def getargspec(func):
        full = inspect.getfullargspec(func)
        return full.args, full.varargs, full.varkw, full.defaults
    inspect.getargspec = getargspec

# загружаем конфиг дома
_CFG_PATH = Path(__file__).parent.parent / "config" / "house.yaml"
_DATA = yaml.safe_load(_CFG_PATH.read_text(encoding="utf-8"))

_morph = MorphAnalyzer()

def _lemmatize(text: str) -> list[str]:
    tokens = text.split()
    return [_morph.parse(tok)[0].normal_form for tok in tokens]

def parse_room_device(text: str) -> dict:
    lemmas = _lemmatize(text.lower())
    room_id = None
    device_id = None

    # ищем комнату по лемматизированным алиасам
    for room in _DATA.get("rooms", []):
        for alias in [room.get("id",""), room.get("name","")] + room.get("aliases", []):
            alias_lemmas = _lemmatize(alias.lower())
            if alias_lemmas and all(l in lemmas for l in alias_lemmas):
                room_id = room["id"]
                break
        if room_id:
            break

    # ищем устройство по лемматизированным алиасам
    for room in _DATA.get("rooms", []):
        for dev in room.get("devices", {}).get("lights", []):
            for alias in [dev.get("entity_id",""), dev.get("name","")] + dev.get("aliases", []):
                alias_lemmas = _lemmatize(alias.lower())
                if alias_lemmas and all(l in lemmas for l in alias_lemmas):
                    device_id = dev["entity_id"]
                    if room_id is None:
                        room_id = room["id"]
                    break
            if device_id:
                break
        if device_id:
            break

    return {"room_id": room_id, "device_id": device_id}

def get_device_info(room_id: str, device_id: str) -> dict | None:
    for room in _DATA.get("rooms", []):
        if room["id"] == room_id:
            for dev in room.get("devices", {}).get("lights", []):
                if dev["entity_id"] == device_id:
                    return dev
    return None
